<?php
class Database_Mysql_Exception extends Exception
{

}